const button = document.querySelector("#bnt1")

button.addEventListener("click", function(){
    window.alert("hola mundo")
})