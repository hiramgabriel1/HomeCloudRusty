// const file = document.querySelector(".file");

// file.addEventListener("click", function(){
//     console.log("hjola")
//     console.log(file)
// })